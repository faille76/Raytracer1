/*
**
*/

#ifndef			__LAPIN_ENUM_COMPAT_H__
# define		__LAPIN_ENUM_COMPAT_H__
# include		"lapin/basic.h"
#endif	/*		__LAPIN_ENUM_COMPAT_H__	*/

