// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

void			bunny_set_click_response(t_bunny_click	click)
{
  gl_callback.click = click;
}

