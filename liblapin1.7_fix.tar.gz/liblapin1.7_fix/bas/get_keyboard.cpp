// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

const bool		*bunny_get_keyboard(void)
{
  return (gl_keyboard);
}
