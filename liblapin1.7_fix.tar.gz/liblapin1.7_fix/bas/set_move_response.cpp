// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

void			bunny_set_move_response(t_bunny_move	move)
{
  gl_callback.move = move;
}

