// Jason Brillante "Damdoshi"
// Epitech 1999-2042
//
// Bibliotheque Lapin

#include		"lapin_private.h"

void			bunny_set_loop_main_function(t_bunny_loop	loop)
{
  gl_callback.loop = loop;
}

